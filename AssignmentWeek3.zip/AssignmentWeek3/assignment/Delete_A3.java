package week3.assignment;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.*;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Delete_A3 {
	@Test
	public void delete_Assignment3(){
	// Requirements
			// End point with resources
			RestAssured.baseURI = "https://dev96914.service-now.com/api/now/table/change_request/";
			RestAssured.authentication = RestAssured.basic("admin", "x8aBj-Yz/BQ1");
			
			RequestSpecification inputRequest = RestAssured.given()
					.contentType(ContentType.JSON).log().all()
					;

			// send the request
			Response response = inputRequest.delete("beb1960797a31110592a39000153af63");
			// validate the response
						response.then().log().all();
			//assertion
			response.then().assertThat().statusCode(204);
			//verify the status line
			String statusLine = response.getStatusLine();
			    Assert.assertEquals(statusLine /*actual value*/, "HTTP/1.1 204 No Content" , "Correct status code returned");
			
		}
}

