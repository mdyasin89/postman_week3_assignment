package week3.assignment;

import java.io.File;

import org.testng.annotations.Test;

public class SearchJira extends BaseClassImpl {
	
	@Test(dependsOnMethods = { "week3.assignment.CreateJira.createJiraTest"})
	public void searchAllJiraTest() {
		 response = request.get("issue/"+jira_id);
		response.then().assertThat().statusCode(200);
	}

}
