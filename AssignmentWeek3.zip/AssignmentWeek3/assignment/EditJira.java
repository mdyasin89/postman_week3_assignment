package week3.assignment;

import java.io.File;

import org.testng.annotations.Test;

public class EditJira extends BaseClassImpl {
	
	@Test(dependsOnMethods = { "week3.assignment.CreateJira.createJiraTest"})
	public void editJiraTest() {
		//File jiraEdit= new File("./src/test/resources/jiraEdit.json");
		response = request.body("{\"fields\": {\"description\": \"Bug creation Using REST API for testingNew\"}}").put("issue/"+jira_id);
		response.then().assertThat().statusCode(204);
	}

}
