package week3.assignment;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.*;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;

public class Update_Patch_A2 {
	@Test
	public void updateReqUsingPatch(){
	// Requirements
			// End point with resources
			RestAssured.baseURI = "https://dev96914.service-now.com/api/now/table/change_request/";
			RestAssured.authentication = RestAssured.basic("admin", "x8aBj-Yz/BQ1");
			RequestSpecification inputRequest = RestAssured.given()
					.body("{\"short_description\":\"using patch method for hamcrest5\",\"description\":\"Description yas2 changes12-08\"}")
					.contentType(ContentType.JSON).log().all()
					;

			// send the request
			Response response = inputRequest.patch("1b7cdba6972f95501d383d400153af3c");
			// validate the response
						response.then().log().all();
			//assertion
			response.then().assertThat().statusCode(200)
			.body("result.short_description", Matchers.equalTo("using patch method for hamcrest5"))
			;
			ResponseBody body = response.getBody();
			String bodyString=response.getBody().asString();
			Assert.assertEquals(bodyString.contains("hamcrest") /*Expected value*/, true /*Actual Value*/, "Response body contains hamcrest");
			//verify the status line
			String statusLine = response.getStatusLine();
			    Assert.assertEquals(statusLine /*actual value*/, "HTTP/1.1 200 OK" , "Correct status code returned");
		}
}

