package week3.assignment;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;
import io.restassured.*;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Update_Put_A1 {
	@Test
	public void updateReqUsingPut(){
	// Requirements
			// End point with resources
			RestAssured.baseURI = "https://dev96914.service-now.com/api/now/table/change_request/";
			RestAssured.authentication = RestAssured.basic("admin", "x8aBj-Yz/BQ1");
			
			RequestSpecification inputRequest = RestAssured.given()
					.body("{\"short_description\":\"using put method for hemcr4est\",\"description\":\"Description yas2 changesnew\"}")
					.contentType(ContentType.JSON).log().all()
					;

			// send the request
			Response response = inputRequest.put("1b7cdba6972f95501d383d400153af3c");
			// validate the response
						response.then().log().all();
			//assertion
			response.then().assertThat().statusCode(200);
			
		}
}

