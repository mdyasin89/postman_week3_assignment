package week3.assignment;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BaseClassImpl {
	static RequestSpecification request=null;
	 static String jira_id=null;
	 static String jira_key=null;
	 static Response response=null;
	
	@BeforeMethod
	public void setup() {
		RestAssured.baseURI = "https://mahdi2018.atlassian.net/rest/api/2/";
		RestAssured.authentication = RestAssured.preemptive().basic("mdyasin89@gmail.com", "IwUUljpvit3UAnFcpIXtB541");
		
		request = RestAssured.given().contentType(ContentType.JSON).log().all();

	}
	
	@AfterMethod
	public void tearDown() {
		response.then().log().all();
	}

}
