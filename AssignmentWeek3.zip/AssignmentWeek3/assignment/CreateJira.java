package week3.assignment;

import java.io.File;

import org.testng.annotations.Test;

public class CreateJira extends BaseClassImpl {
	@Test
	public void createJiraTest() {
		File jiraCreate= new File("./src/test/resources/jiraCreate.json");
		
		response = request.body(jiraCreate).post("issue/");
		//Assert.assertEquals(true, false);
		
		jira_id = response.jsonPath().get("id");
		System.out.println("Sys_id=== "+jira_id);
		jira_key = response.jsonPath().get("key");
		System.out.println("Sys_id=== "+jira_key);
		response.then().assertThat().statusCode(201);
//		throw new RuntimeException();
	}

}
