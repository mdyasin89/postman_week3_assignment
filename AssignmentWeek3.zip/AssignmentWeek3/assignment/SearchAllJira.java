package week3.assignment;

import java.io.File;

import org.testng.annotations.Test;

public class SearchAllJira extends BaseClassImpl {
	
	@Test()
	public void searchAllJiraTest() {
		 response = request.queryParam("jql", "project=\"yasin3\"").get("search/");
		response.then().assertThat().statusCode(200);
	}

}
