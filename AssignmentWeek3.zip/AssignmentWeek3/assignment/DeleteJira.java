package week3.assignment;

import java.io.File;

import org.testng.annotations.Test;

public class DeleteJira extends BaseClassImpl {
	
	@Test(dependsOnMethods = { "week3.assignment.CreateJira.createJiraTest"})
	public void deleteJiraTest() {
		response = request.delete("issue/"+jira_id);
		response.then().assertThat().statusCode(204);
	}

}
